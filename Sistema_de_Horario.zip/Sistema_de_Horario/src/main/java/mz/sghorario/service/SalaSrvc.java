package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Sala;
import mz.sghorario.repository.SalasRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class SalaSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private SalasRepo salasRepo;

	@Transactional
	public void guardar(Sala sala) throws NegocioException {

		Sala salaExiste = salasRepo.salaExiste(sala.getNome());
		if (salaExiste != null && !salaExiste.equals(sala)) {
			throw new NegocioException("O nome da sala já existe...");
		}
		this.salasRepo.adicionar(sala);
	}
}
