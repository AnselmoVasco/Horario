package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Horario;
import mz.sghorario.repository.HorariosRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class HorarioSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private HorariosRepo horariosRepo;

	@Transactional
	public void guardar(Horario horario) throws NegocioException {

		Horario salaOcupada = horariosRepo.salaOcupada(horario.getDias(),
				horario.getTempo().getCodigo(), horario.getSala().getCodigo(),
				horario.getSemestre());

		Horario professorOcupado = horariosRepo.professorOcupado(horario
				.getDias(), horario.getSemestre(), horario.getTempo()
				.getCodigo(), horario.getProfessor().getCodigo());

		Horario horarioExiste = horariosRepo.HorarioLancado(horario.getCurso()
				.getCodigo(), horario.getDias(), horario.getAno(), horario
				.getSemestre(), horario.getPeriodo(), horario.getTempo()
				.getCodigo());

		if (salaOcupada != null && !salaOcupada.equals(horario)) {
			throw new NegocioException(
					"A Sala está ocupada neste dia de semana e hora indicada...");
		}

		if (professorOcupado != null && !professorOcupado.equals(horario)) {
			throw new NegocioException(
					"O Professor está ocupado a esta hora e dia de semana...");
		}

		if (horarioExiste != null && !horarioExiste.equals(horario)) {
			throw new NegocioException("Este horário já foi lançado...");
		}

		this.horariosRepo.adicionar(horario);

	}
}
