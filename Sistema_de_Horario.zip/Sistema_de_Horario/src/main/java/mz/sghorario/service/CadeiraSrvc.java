package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.repository.CadeirasRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class CadeiraSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadeirasRepo cadeirasRepo;

	@Transactional
	public void guardar(Cadeira cadeira) throws NegocioException {
		Cadeira cadeiraExiste = cadeirasRepo.mesmoNome(cadeira.getNome());

		if (cadeiraExiste != null && !cadeiraExiste.equals(cadeira)) {
			throw new NegocioException("Este nome já existe...");
		}

		this.cadeirasRepo.adicionar(cadeira);
	}

}
