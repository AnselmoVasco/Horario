package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Departamento;
import mz.sghorario.repository.DepartamentosRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class DepartamentoSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private DepartamentosRepo departamentosRepo;

	@Transactional
	public void guardar(Departamento departamento) throws NegocioException {

		Departamento depeNomeExiste = departamentosRepo.mesmoNome(departamento
				.getNome());
		Departamento depSiglaExiste = departamentosRepo.mesmaSigla(departamento
				.getSigla());
		if (depeNomeExiste != null && !depeNomeExiste.equals(departamento)) {
			throw new NegocioException("Este nome já existe...");
		}
		if (depSiglaExiste != null && !depSiglaExiste.equals(departamento)) {
			throw new NegocioException("Esta sigla já existe...");
		}
		this.departamentosRepo.adicionar(departamento);
	}

}
