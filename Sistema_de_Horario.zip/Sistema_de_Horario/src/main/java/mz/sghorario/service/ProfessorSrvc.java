package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Professor;
import mz.sghorario.repository.ProfessoresRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class ProfessorSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ProfessoresRepo professoresRepo;

	@Transactional
	public void guardar(Professor professor) throws NegocioException {
		Professor bilheteExiste = professoresRepo.bilheteExiste(professor
				.getBilhete());

		if (bilheteExiste != null && !bilheteExiste.equals(professor)) {
			throw new NegocioException("O bilhete informado já existe...");
		}

		this.professoresRepo.adicionar(professor);
	}
}
