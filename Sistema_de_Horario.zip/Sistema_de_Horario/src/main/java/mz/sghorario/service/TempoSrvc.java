package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Tempo;
import mz.sghorario.repository.TemposRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class TempoSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private TemposRepo temposRepo;

	@Transactional
	public void guardar(Tempo tempo) throws NegocioException {
		Tempo tempoExistente = temposRepo.restricao(tempo.getHoraEntrada(),
				tempo.getHoraSaida());
		if (tempo.getHoraEntrada().equals(tempo.getHoraSaida())) {
			throw new NegocioException(
					"A hora de entrada e saida não devem ser iguais...");
		}
		if (tempoExistente != null && !tempoExistente.equals(tempo)) {
			throw new NegocioException(
					"A hora de entrada e saida já estão sendo usadas...");
		} else {
			this.temposRepo.adicionar(tempo);
		}
	}
}
