package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Usuario;
import mz.sghorario.repository.UsuariosRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class UsuarioSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private UsuariosRepo usuariosRepo;

	@Transactional
	public void guardar(Usuario usuario) throws NegocioException {
		Usuario emailExiste = usuariosRepo.enderecoUnico(usuario.getEmail());
		Usuario bilheteExiste = usuariosRepo
				.bilheteExiste(usuario.getBilhete());
		Usuario numeroExiste = usuariosRepo.numeroExiste(usuario
				.getNumeroTelefone());

		if (emailExiste != null && !emailExiste.equals(usuario)) {
			throw new NegocioException("O E-mail já está em uso...");
		}
		if (bilheteExiste != null && !bilheteExiste.equals(usuario)) {
			throw new NegocioException("O nº de bilhete já está em uso...");
		}
		if (numeroExiste != null && !numeroExiste.equals(usuario)) {
			throw new NegocioException("O nº de telefone já está em uso...");
		}

		this.usuariosRepo.adicionar(usuario);
	}
}
