package mz.sghorario.service;

import java.io.Serializable;

import javax.inject.Inject;

import mz.sghorario.modelo.Curso;
import mz.sghorario.repository.CursosRepo;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.Transactional;

public class CursoSrvc implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CursosRepo cursosRepo;

	@Transactional
	public void guardar(Curso curso) throws NegocioException {
		Curso cursoExistente = cursosRepo.cursoExiste(curso.getNome(),
				curso.getNivel());

		if (cursoExistente != null && !cursoExistente.equals(curso)) {
			throw new NegocioException("Este curso já existe...");

		}

		this.cursosRepo.adicionar(curso);
	}
}
