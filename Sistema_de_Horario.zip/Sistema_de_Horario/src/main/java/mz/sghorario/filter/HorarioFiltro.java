package mz.sghorario.filter;

import java.io.Serializable;

import mz.sghorario.modelo.EnumAnos;
import mz.sghorario.modelo.EnumPeriodo;
import mz.sghorario.modelo.EnumSemestre;

public class HorarioFiltro implements Serializable {

	private static final long serialVersionUID = 1L;
	private String ano;
	private Long curso;
	private EnumSemestre semestre;
	private EnumPeriodo periodo;
	private EnumAnos anoLectivo;

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public Long getCurso() {
		return curso;
	}

	public void setCurso(Long curso) {
		this.curso = curso;
	}

	public EnumSemestre getSemestre() {
		return semestre;
	}

	public void setSemestre(EnumSemestre semestre) {
		this.semestre = semestre;
	}

	public EnumPeriodo getPeriodo() {
		return periodo;
	}

	public void setPeriodo(EnumPeriodo periodo) {
		this.periodo = periodo;
	}

	public EnumAnos getAnoLectivo() {
		return anoLectivo;
	}

	public void setAnoLectivo(EnumAnos anoLectivo) {
		this.anoLectivo = anoLectivo;
	}
}
