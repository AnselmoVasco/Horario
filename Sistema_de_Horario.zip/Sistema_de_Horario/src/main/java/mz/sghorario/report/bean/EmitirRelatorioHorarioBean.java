package mz.sghorario.report.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.hibernate.Session;
import org.hibernate.validator.constraints.NotEmpty;

import mz.sghorario.modelo.Curso;
import mz.sghorario.modelo.EnumAnos;
import mz.sghorario.modelo.EnumPeriodo;
import mz.sghorario.modelo.EnumSemestre;
import mz.sghorario.repository.CursosRepo;
import mz.sghorario.util.FacesUtil;
import mz.sghorario.util.report.ExecutorRelatorio;

@Named
@ViewScoped
public class EmitirRelatorioHorarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CursosRepo cursosRepo;

	@Inject
	private FacesContext facesContext;

	@Inject
	private HttpServletResponse response;

	@Inject
	private EntityManager manager;

	private List<Curso> todosCursos;

	// Campos enumeração para serem listados na página
	@SuppressWarnings("unused")
	private EnumAnos todosAnos;

	@SuppressWarnings("unused")
	private EnumSemestre semestre;

	@SuppressWarnings("unused")
	private EnumPeriodo periodo;

	// Parametros do banco, aqui teremos Strings enves de Enumeration
	private Long curso;
	private String anoCurso;
	private String semestreParam;
	private String periodoParam;
	private String todosAnosParam;

	public void carregaCursos() {
		this.todosCursos = cursosRepo.todos();
	}

	public void emitir() {
		Map<String, Object> parametros = new HashMap<>();

		parametros.put("todosAnosParam", this.todosAnosParam);
		parametros.put("semestreParam", this.semestreParam);
		parametros.put("periodoParam", this.periodoParam);
		parametros.put("curso", this.curso);
		parametros.put("anoCurso", this.anoCurso);

		ExecutorRelatorio executor = new ExecutorRelatorio(
				"/relatorio/Horario.jasper", this.response, parametros,
				"Horario_FCSP.pdf");

		Session session = manager.unwrap(Session.class);
		session.doWork(executor);

		if (executor.isRelatorioGerado()) {
			facesContext.responseComplete();
		} else {
			FacesUtil.addMsgERRO("A execução do relatório não retornou dados.");
		}
	}

	public EnumAnos[] getTodosAnos() {
		return EnumAnos.values();
	}

	public List<Curso> getTodosCursos() {
		return todosCursos;
	}

	public EnumSemestre[] getSemestre() {
		return EnumSemestre.values();
	}

	public EnumPeriodo[] getPeriodo() {
		return EnumPeriodo.values();
	}

	@NotNull
	public Long getCurso() {
		return curso;
	}

	public void setCurso(Long curso) {
		this.curso = curso;
	}

	@NotEmpty
	public String getAnoCurso() {
		return anoCurso;
	}

	public void setAnoCurso(String anoCurso) {
		this.anoCurso = anoCurso;
	}

	@NotEmpty
	public String getSemestreParam() {
		return semestreParam;
	}

	public void setSemestreParam(String semestreParam) {
		this.semestreParam = semestreParam;
	}

	@NotEmpty
	public String getPeriodoParam() {
		return periodoParam;
	}

	public void setPeriodoParam(String periodoParam) {
		this.periodoParam = periodoParam;
	}

	@NotEmpty
	public String getTodosAnosParam() {
		return todosAnosParam;
	}

	public void setTodosAnosParam(String todosAnosParam) {
		this.todosAnosParam = todosAnosParam;
	}

}
