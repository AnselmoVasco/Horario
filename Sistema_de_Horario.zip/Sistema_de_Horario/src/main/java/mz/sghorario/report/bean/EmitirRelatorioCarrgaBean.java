package mz.sghorario.report.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.hibernate.Session;
import org.hibernate.validator.constraints.NotEmpty;

import mz.sghorario.modelo.EnumAnos;
import mz.sghorario.modelo.EnumSemestre;
import mz.sghorario.util.FacesUtil;
import mz.sghorario.util.report.ExecutorRelatorio;

@Named
@ViewScoped
public class EmitirRelatorioCarrgaBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private FacesContext facesContext;

	@Inject
	private HttpServletResponse response;

	@Inject
	private EntityManager manager;

	@SuppressWarnings("unused")
	private EnumAnos anos;

	@SuppressWarnings("unused")
	private EnumSemestre semestre;

	private Long professor;
	private String anoActual;
	private String semestreParam;

	public void emitir() {
		Map<String, Object> parametros = new HashMap<>();

		parametros.put("anoActual", this.anoActual);
		parametros.put("professor", this.professor);
		parametros.put("semestreParam", this.semestreParam);

		ExecutorRelatorio executor = new ExecutorRelatorio(
				"/relatorio/HorarioProfessor.jasper", this.response,
				parametros, "CarrgaHoraria_FCSP.pdf");

		Session session = manager.unwrap(Session.class);
		session.doWork(executor);

		if (executor.isRelatorioGerado()) {
			facesContext.responseComplete();
		} else {
			FacesUtil.addMsgERRO("A execução do relatório não retornou dados.");
		}
	}

	public EnumAnos[] getAnos() {
		return EnumAnos.values();
	}

	public EnumSemestre[] getSemestre() {
		return EnumSemestre.values();
	}

	@NotNull
	public Long getProfessor() {
		return professor;
	}

	public void setProfessor(Long professor) {
		this.professor = professor;
	}

	@NotEmpty
	public String getAnoActual() {
		return anoActual;
	}

	public void setAnoActual(String anoActual) {
		this.anoActual = anoActual;
	}

	@NotEmpty
	public String getSemestreParam() {
		return semestreParam;
	}

	public void setSemestreParam(String semestreParam) {
		this.semestreParam = semestreParam;
	}

}
