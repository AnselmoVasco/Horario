package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.hibernate.validator.constraints.NotBlank;
import org.primefaces.event.SelectEvent;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.modelo.Curso;
import mz.sghorario.modelo.EnumAnos;
import mz.sghorario.modelo.EnumDias;
import mz.sghorario.modelo.EnumPeriodo;
import mz.sghorario.modelo.EnumSemestre;
import mz.sghorario.modelo.Horario;
import mz.sghorario.modelo.Professor;
import mz.sghorario.modelo.Sala;
import mz.sghorario.modelo.Tempo;
import mz.sghorario.repository.HorariosRepo;
import mz.sghorario.service.HorarioSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class HorarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Horario horario;

	@Inject
	private HorariosRepo horariosRepo;

	@Inject
	private HorarioSrvc horarioSrvc;

	private List<Horario> todosHorarios;
	private List<Horario> horarioFiltro;

	public void carregaHorarios() {
		this.todosHorarios = horariosRepo.todos();
		if (this.horario == null) {
			this.horario = new Horario();
		}
	}

	public void cadastrar() {
		try {
			horarioSrvc.guardar(this.horario);
			this.horario = new Horario();

			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			horariosRepo.remover(this.horario);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/criarHorario.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover horário");
		}
		return null;
	}

	public void cadeiraSeleccionada(SelectEvent event) {
		Cadeira cadeira = (Cadeira) event.getObject();

		horario.setCadeira(cadeira);
	}

	public void salaSeleccionada(SelectEvent event) {
		Sala sala = (Sala) event.getObject();

		horario.setSala(sala);
	}

	public void tempoSeleccionado(SelectEvent event) {
		Tempo tempo = (Tempo) event.getObject();

		horario.setTempo(tempo);
	}

	public void professorSeleccionado(SelectEvent event) {
		Professor professor = (Professor) event.getObject();

		horario.setProfessor(professor);
	}

	public void CursoSeleccionado(SelectEvent event) {
		Curso curso = (Curso) event.getObject();

		horario.setCurso(curso);
	}

	public Horario getHorario() {
		return horario;
	}

	public void setHorario(Horario horario) {
		this.horario = horario;
	}

	public List<Horario> getHorarioFiltro() {
		return horarioFiltro;
	}

	public void setHorarioFiltro(List<Horario> horarioFiltro) {
		this.horarioFiltro = horarioFiltro;
	}

	public List<Horario> getTodosHorarios() {
		return todosHorarios;
	}

	public EnumDias[] getEnumDias() {
		return EnumDias.values();
	}

	public EnumPeriodo[] getEnumPeriodos() {
		return EnumPeriodo.values();
	}

	public EnumSemestre[] getEnumSemestres() {
		return EnumSemestre.values();
	}

	public EnumAnos[] getEnumAnos() {
		return EnumAnos.values();
	}

	@NotBlank
	public String getNomeCadeira() {
		return horario.getCadeira() == null ? null : horario.getCadeira()
				.getNome();
	}

	public void setNomeCadeira(String nome) {

	}

	@NotBlank
	public String getNomeCurso() {
		return horario.getCurso() == null ? null : horario.getCurso().getNome();
	}

	public void setNomeCurso(String nome) {

	}

	@NotBlank
	public String getNomeProfessor() {
		return horario.getProfessor() == null ? null : horario.getProfessor()
				.getNome();
	}

	public void setNomeProfessor(String nome) {

	}

	@NotBlank
	public String getNomeSala() {
		return horario.getSala() == null ? null : horario.getSala().getNome();
	}

	public void setNomeSala(String nome) {

	}

	@NotBlank
	public String getHoraEntrada() {
		return horario.getTempo() == null ? null : horario.getTempo()
				.getHoraEntrada();
	}

	public void setHoraEntrada(String horaEntrada) {

	}
}
