package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.modelo.EnumSemestre;
import mz.sghorario.repository.CadeirasRepo;
import mz.sghorario.service.CadeiraSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class CadeiraBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Cadeira cadeiraCadastro;;

	@Inject
	private CadeirasRepo cadeirasRepo;

	@Inject
	private CadeiraSrvc cadeiraSrvc;

	private List<Cadeira> todasCadeiras;
	private List<Cadeira> cadeiraFiltrada;

	public void carregaCadeiras() {
		this.todasCadeiras = cadeirasRepo.todas();
		if (this.cadeiraCadastro == null) {
			this.cadeiraCadastro = new Cadeira();
		}
	}

	public void cadastrar() {
		try {
			cadeiraSrvc.guardar(this.cadeiraCadastro);
			this.cadeiraCadastro = new Cadeira();

			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			cadeirasRepo.remover(this.cadeiraCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/cadeira.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover cadeira");
		}
		return null;
	}

	public List<Cadeira> getCadeiraFiltrada() {
		return cadeiraFiltrada;
	}

	public void setCadeiraFiltrada(List<Cadeira> cadeiraFiltrada) {
		this.cadeiraFiltrada = cadeiraFiltrada;
	}

	public List<Cadeira> getTodasCadeiras() {
		return todasCadeiras;
	}

	public Cadeira getCadeiraCadastro() {
		return cadeiraCadastro;
	}

	public void setCadeiraCadastro(Cadeira cadeiraCadastro) {
		this.cadeiraCadastro = cadeiraCadastro;
	}

	public EnumSemestre[] getSemestres() {
		return EnumSemestre.values();
	}
}
