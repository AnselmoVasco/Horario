package mz.sghorario.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;

import mz.sghorario.modelo.Departamento;
import mz.sghorario.modelo.Local;
import mz.sghorario.modelo.Professor;
import mz.sghorario.repository.DepartamentosRepo;
import mz.sghorario.repository.LocalRepo;
import mz.sghorario.repository.ProfessoresRepo;
import mz.sghorario.service.ProfessorSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class ProfessorBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Professor professorCadastro;

	@Inject
	private Professor professorSelecionado;

	@Inject
	private ProfessoresRepo professoresRepo;

	@Inject
	private ProfessorSrvc professorServico;

	@Inject
	private DepartamentosRepo departamentosRepo;

	private List<Professor> todosProfessores;
	private List<Professor> professorFiltro;

	private List<Departamento> todosDepartamentos;

	private List<Local> locais;

	@Inject
	private Local local;

	@Inject
	private LocalRepo localRepo;

	private javax.servlet.http.Part fotografia;

	public void carregaDepartamentos() {
		todosDepartamentos = this.departamentosRepo.todos();
	}

	public void carregaProfessores() {
		this.todosProfessores = professoresRepo.todos();
		if (this.professorCadastro == null) {
			this.professorCadastro = new Professor();
		}
	}

	public void cadastrar() {
		try {
			professorServico.guardar(this.professorCadastro);
			this.professorCadastro = new Professor();

			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			professoresRepo.remover(this.professorCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/professor.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover professor");
		}
		return null;
	}

	public void salvarImagem() {
		try {
			InputStream is = fotografia.getInputStream();
			// código usando Apache Commons IO
			byte[] bytes = IOUtils.toByteArray(is);
			local.setImagem(bytes);
			local.setProfessor(professorSelecionado);
			localRepo.adicionar(local);
			FacesUtil.addMsgINFO("Dados do professor "
					+ professorSelecionado.getNome() + ", "
					+ "guardados com sucesso");
		} catch (IOException e) {
			FacesUtil.addMsgAviso(e.getMessage());
		}
	}

	public void listaFotoProfessor() {

		try {
			ServletContext sContext = (ServletContext) FacesContext
					.getCurrentInstance().getExternalContext().getContext();

			locais = localRepo.listarLocaisPorProfessor(professorSelecionado
					.getCodigo());

			File folder = new File(sContext.getRealPath("/temp"));

			if (!folder.exists())
				folder.mkdirs();

			for (Local f : locais) {
				String nomeArquivo = f.getCodigo() + ".jpg";
				String arquivo = sContext.getRealPath("/temp") + File.separator
						+ nomeArquivo;

				criaArquivo(f.getImagem(), arquivo);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void criaArquivo(byte[] bytes, String arquivo) {
		FileOutputStream fos;

		try {
			fos = new FileOutputStream(arquivo);
			fos.write(bytes);

			fos.flush();
			fos.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public List<Professor> getTodosProfessores() {
		return todosProfessores;
	}

	public List<Professor> getProfessorFiltro() {
		return professorFiltro;
	}

	public void setProfessorFiltro(List<Professor> professorFiltro) {
		this.professorFiltro = professorFiltro;
	}

	public Professor getProfessorCadastro() {
		return professorCadastro;
	}

	public void setProfessorCadastro(Professor professorCadastro) {
		this.professorCadastro = professorCadastro;
	}

	public List<Departamento> getTodosDepartamentos() {
		return todosDepartamentos;
	}

	public void setTodosDepartamentos(List<Departamento> todosDepartamentos) {
		this.todosDepartamentos = todosDepartamentos;
	}

	public javax.servlet.http.Part getFotografia() {
		return fotografia;
	}

	public void setFotografia(javax.servlet.http.Part fotografia) {
		this.fotografia = fotografia;
	}

	public Professor getProfessorSelecionado() {
		return professorSelecionado;
	}

	public void setProfessorSelecionado(Professor professorSelecionado) {
		this.professorSelecionado = professorSelecionado;
	}

	public List<Local> getLocais() {
		return locais;
	}

	public void setLocais(List<Local> locais) {
		this.locais = locais;
	}

	public Local getLocal() {
		return local;
	}

	public void setLocal(Local local) {
		this.local = local;
	}

}
