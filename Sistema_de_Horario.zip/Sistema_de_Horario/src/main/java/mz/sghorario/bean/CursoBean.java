package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.Curso;
import mz.sghorario.modelo.Departamento;
import mz.sghorario.modelo.EnumNivel;
import mz.sghorario.repository.CursosRepo;
import mz.sghorario.repository.DepartamentosRepo;
import mz.sghorario.service.CursoSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class CursoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Curso cursoCadastro;

	@Inject
	private DepartamentosRepo departamentosRepo;

	@Inject
	private CursosRepo cursosRepo;

	@Inject
	private CursoSrvc cursoSrvc;

	private List<Curso> todosCursos;
	private List<Curso> cursoFiltrado;
	private List<Departamento> todosDepartamentos;

	public void carregaDepartamentos() {
		this.todosDepartamentos = departamentosRepo.todos();
	}

	public void carregaCursos() {
		this.todosCursos = cursosRepo.todos();
		if (this.cursoCadastro == null) {
			this.cursoCadastro = new Curso();
		}
	}

	public void cadastrar() {

		try {
			cursoSrvc.guardar(this.cursoCadastro);

			this.cursoCadastro = new Curso();
			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			cursosRepo.remover(this.cursoCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/curso.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover curso");
		}
		return null;

	}

	public List<Curso> getTodosCursos() {
		return todosCursos;
	}

	public Curso getCursoCadastro() {
		return cursoCadastro;
	}

	public void setCursoCadastro(Curso cursoCadastro) {
		this.cursoCadastro = cursoCadastro;
	}

	public List<Curso> getCursoFiltrado() {
		return cursoFiltrado;
	}

	public void setCursoFiltrado(List<Curso> cursoFiltrado) {
		this.cursoFiltrado = cursoFiltrado;
	}

	public List<Departamento> getTodosDepartamentos() {
		return todosDepartamentos;
	}

	public EnumNivel[] getEnumNivels() {
		return EnumNivel.values();
	}

}
