package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.Departamento;
import mz.sghorario.repository.DepartamentosRepo;
import mz.sghorario.service.DepartamentoSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class DepartamentoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Departamento departamentoCadastro;

	private List<Departamento> todosDepartamentos;
	private List<Departamento> departamentoFiltro;

	@Inject
	private DepartamentosRepo depRepository;

	@Inject
	private DepartamentoSrvc departamentoSrvc;

	public List<String> pesquisarDepartamentos(String nome) {
		return this.depRepository.departamentoQueContem(nome);
	}

	public void carregarDepartamentos() {
		this.todosDepartamentos = this.depRepository.todos();
		if (this.departamentoCadastro == null) {
			this.departamentoCadastro = new Departamento();
		}
	}

	public void cadastrar() {
		try {
			departamentoSrvc.guardar(this.departamentoCadastro);
			this.departamentoCadastro = new Departamento();

			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException e) {
			FacesUtil.addMsgAviso(e.getMessage());
		}
	}

	public String remover() {
		try {
			depRepository.remover(this.departamentoCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/departamento.xhtml?faces-redirect=true";

		} catch (RuntimeException e) {
			FacesUtil.addMsgERRO("Erro ao remover departamento");
		}
		return null;
	}

	public Departamento getDepartamentoCadastro() {
		return departamentoCadastro;
	}

	public void setDepartamentoCadastro(Departamento departamentoCadastro) {
		this.departamentoCadastro = departamentoCadastro;
	}

	public List<Departamento> getTodosDepartamentos() {
		return todosDepartamentos;
	}

	public List<Departamento> getDepartamentoFiltro() {
		return departamentoFiltro;
	}

	public void setDepartamentoFiltro(List<Departamento> departamentoFiltro) {
		this.departamentoFiltro = departamentoFiltro;
	}
}
