package mz.sghorario.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import mz.sghorario.modelo.Curso;
import mz.sghorario.repository.CursosRepo;

@Named
@ViewScoped
public class SeleccaoCurso implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CursosRepo cursosRepo;

	private String nome;
	private List<Curso> cursoFiltro;

	public void FiltroCursosDialogo() {
		this.cursoFiltro = cursosRepo.todosDialog(nome);
	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 500);

		RequestContext.getCurrentInstance().openDialog("cursoPesquisa", opcoes,
				null);
	}

	public void selecionar(Curso curso) {
		RequestContext.getCurrentInstance().closeDialog(curso);
	}

	public List<Curso> getCursoFiltro() {
		return cursoFiltro;
	}

	public void setCursoFiltro(List<Curso> cursoFiltro) {
		this.cursoFiltro = cursoFiltro;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
