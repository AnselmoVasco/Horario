package mz.sghorario.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import mz.sghorario.modelo.Sala;
import mz.sghorario.repository.SalasRepo;

@Named
@ViewScoped
public class SeleccaoSala implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private SalasRepo salasRepo;

	private String nome;
	private List<Sala> salaFiltro;

	public void fitroSalaDialogo() {
		this.salaFiltro = salasRepo.todosDialog(nome);
	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 500);

		RequestContext.getCurrentInstance().openDialog("salaPesquisa", opcoes,
				null);
	}

	public void selecionar(Sala sala) {
		RequestContext.getCurrentInstance().closeDialog(sala);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<Sala> getSalaFiltro() {
		return salaFiltro;
	}

	public void setSalaFiltro(List<Sala> salaFiltro) {
		this.salaFiltro = salaFiltro;
	}
}
