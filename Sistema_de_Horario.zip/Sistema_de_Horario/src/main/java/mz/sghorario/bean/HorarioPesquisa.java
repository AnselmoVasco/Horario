package mz.sghorario.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletContext;

import mz.sghorario.filter.HorarioFiltro;
import mz.sghorario.modelo.Curso;
import mz.sghorario.modelo.Horario;
import mz.sghorario.modelo.Local;
import mz.sghorario.repository.CursosRepo;
import mz.sghorario.repository.HorariosRepo;
import mz.sghorario.repository.LocalRepo;

@Named
@ViewScoped
public class HorarioPesquisa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CursosRepo cursosRepo;

	@Inject
	private HorariosRepo horariosRepo;

	@Inject
	private HorarioFiltro filtro;

	@Inject
	private Horario horarioSelecionado;

	@Inject
	private Local local;

	@Inject
	private LocalRepo localRepo;

	private List<Local> locais;
	private List<Horario> horarioFiltro;
	private List<Curso> todosCurs;

	public void carregaCursos() {
		this.todosCurs = cursosRepo.todos();
	}

	public void consultar() {
		this.horarioFiltro = horariosRepo.consultar(filtro);
	}

	public void listaFotoProfessor() {

		try {
			ServletContext sContext = (ServletContext) FacesContext
					.getCurrentInstance().getExternalContext().getContext();

			locais = localRepo.listarLocaisPorProfessor(horarioSelecionado
					.getProfessor().getCodigo());

			File folder = new File(sContext.getRealPath("/temp"));

			if (!folder.exists())
				folder.mkdirs();

			for (Local f : locais) {
				String nomeArquivo = f.getCodigo() + ".jpg";
				String arquivo = sContext.getRealPath("/temp") + File.separator
						+ nomeArquivo;

				criaArquivo(f.getImagem(), arquivo);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void criaArquivo(byte[] bytes, String arquivo) {
		FileOutputStream fos;

		try {
			fos = new FileOutputStream(arquivo);
			fos.write(bytes);

			fos.flush();
			fos.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public List<Horario> getHorarioFiltro() {
		return horarioFiltro;
	}

	public void setHorarioFiltro(List<Horario> horarioFiltro) {
		this.horarioFiltro = horarioFiltro;
	}

	public List<Curso> getTodosCurs() {
		return todosCurs;
	}

	public void setTodosCurs(List<Curso> todosCurs) {
		this.todosCurs = todosCurs;
	}

	public HorarioFiltro getFiltro() {
		return filtro;
	}

	public void setFiltro(HorarioFiltro filtro) {
		this.filtro = filtro;
	}

	public Horario getHorarioSelecionado() {
		return horarioSelecionado;
	}

	public void setHorarioSelecionado(Horario horarioSelecionado) {
		this.horarioSelecionado = horarioSelecionado;
	}

	public Local getLocal() {
		return local;
	}

	public void setLocal(Local local) {
		this.local = local;
	}

	public List<Local> getLocais() {
		return locais;
	}

	public void setLocais(List<Local> locais) {
		this.locais = locais;
	}
}
