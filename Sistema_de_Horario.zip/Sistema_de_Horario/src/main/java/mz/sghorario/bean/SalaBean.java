package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.EnumEstado;
import mz.sghorario.modelo.Sala;
import mz.sghorario.repository.SalasRepo;
import mz.sghorario.service.SalaSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class SalaBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Sala salaCadastro;

	@Inject
	private SalasRepo salasRepo;

	@Inject
	private SalaSrvc salaSrvc;

	private List<Sala> todasSalas;
	private List<Sala> salaFiltrada;

	public void carregaSalas() {
		this.todasSalas = salasRepo.todas();
		if (this.salaCadastro == null) {
			this.salaCadastro = new Sala();
		}
	}

	public void cadastrar() {
		try {
			salaSrvc.guardar(this.salaCadastro);
			this.salaCadastro = new Sala();
			FacesUtil.addMsgINFO("Guardado com sucesso");

		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			salasRepo.remover(this.salaCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/sala.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover sala");
		}
		return null;
	}

	public List<Sala> getSalaFiltrada() {
		return salaFiltrada;
	}

	public void setSalaFiltrada(List<Sala> salaFiltrada) {
		this.salaFiltrada = salaFiltrada;
	}

	public List<Sala> getTodasSalas() {
		return todasSalas;
	}

	public Sala getSalaCadastro() {
		return salaCadastro;
	}

	public void setSalaCadastro(Sala salaCadastro) {
		this.salaCadastro = salaCadastro;
	}

	public EnumEstado[] getEstados() {
		return EnumEstado.values();
	}
}
