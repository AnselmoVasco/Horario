package mz.sghorario.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import mz.sghorario.modelo.Professor;
import mz.sghorario.repository.ProfessoresRepo;

@Named
@ViewScoped
public class SeleccaoProfessor implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ProfessoresRepo professoresRepo;

	private String nome;
	private List<Professor> professorFiltro;

	public void FiltroProfessoresDialogo() {
		this.professorFiltro = professoresRepo.todosDialog(nome);

	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 500);

		RequestContext.getCurrentInstance().openDialog("professorPesquisa",
				opcoes, null);
	}

	public void selecionar(Professor professor) {
		RequestContext.getCurrentInstance().closeDialog(professor);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<Professor> getProfessorFiltro() {
		return professorFiltro;
	}

	public void setProfessorFiltro(List<Professor> professorFiltro) {
		this.professorFiltro = professorFiltro;
	}
}
