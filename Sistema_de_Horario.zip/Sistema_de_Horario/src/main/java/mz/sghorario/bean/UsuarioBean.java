package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.EnumFuncao;
import mz.sghorario.modelo.Usuario;
import mz.sghorario.repository.UsuariosRepo;
import mz.sghorario.service.UsuarioSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class UsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Usuario usuarioCadastro;

	@Inject
	private UsuarioSrvc usuarioSrvc;

	@Inject
	private UsuariosRepo usuariosRepo;

	private List<Usuario> todosUsuarios;
	private List<Usuario> usuarioFiltrado;

	public void carregaCadastro() {
		this.todosUsuarios = usuariosRepo.todos();
	}

	public void cadastrar() {
		try {
			usuarioSrvc.guardar(this.usuarioCadastro);
			this.usuarioCadastro = new Usuario();

			FacesUtil.addMsgINFO("Registado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public void numero() {
		todosUsuarios.size();
	}

	public String remover() {
		try {

			usuariosRepo.remover(this.usuarioCadastro);
			FacesUtil.addMsgINFO("Usuario removido com sucesso");

			return "/paginas/conta.xhtml?faces-redirect=true";
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
		return null;
	}

	public List<Usuario> getUsuarioFiltrado() {
		return usuarioFiltrado;
	}

	public void setUsuarioFiltrado(List<Usuario> usuarioFiltrado) {
		this.usuarioFiltrado = usuarioFiltrado;
	}

	public List<Usuario> getTodosUsuarios() {
		return todosUsuarios;
	}

	public Usuario getUsuarioCadastro() {
		return usuarioCadastro;
	}

	public void setUsuarioCadastro(Usuario usuarioCadastro) {
		this.usuarioCadastro = usuarioCadastro;
	}

	public EnumFuncao[] getFuncoes() {
		return EnumFuncao.values();
	}
}
