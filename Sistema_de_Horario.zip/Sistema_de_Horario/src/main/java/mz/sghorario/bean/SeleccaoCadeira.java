package mz.sghorario.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.repository.CadeirasRepo;

@Named
@ViewScoped
public class SeleccaoCadeira implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CadeirasRepo cadeirasRepo;

	private String nome;
	private List<Cadeira> cadeiraFiltro;

	public void fitroCadeiraDialogo() {
		this.cadeiraFiltro = cadeirasRepo.todosDialog(nome);
	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 500);

		RequestContext.getCurrentInstance().openDialog("cadeiraPesquisa",
				opcoes, null);
	}

	public void selecionar(Cadeira cadeira) {
		RequestContext.getCurrentInstance().closeDialog(cadeira);
	}

	public List<Cadeira> getCadeiraFiltro() {
		return cadeiraFiltro;
	}

	public void setCadeiraFiltro(List<Cadeira> cadeiraFiltro) {
		this.cadeiraFiltro = cadeiraFiltro;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
