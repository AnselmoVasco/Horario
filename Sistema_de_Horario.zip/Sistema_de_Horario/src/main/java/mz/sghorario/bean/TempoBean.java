package mz.sghorario.bean;

import java.io.Serializable;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.Tempo;
import mz.sghorario.repository.TemposRepo;
import mz.sghorario.service.TempoSrvc;
import mz.sghorario.service.exception.NegocioException;
import mz.sghorario.util.FacesUtil;

@Named
@ViewScoped
public class TempoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private Tempo tempoCadastro;

	@Inject
	private TempoSrvc tempoSrvc;

	@Inject
	private TemposRepo temposRepo;

	private List<Tempo> todosTempos;
	private List<Tempo> tempoFiltrado;

	public void carregaTempos() {
		this.todosTempos = temposRepo.todos();
		if (this.tempoCadastro == null) {
			this.tempoCadastro = new Tempo();
		}
	}

	public void cadastrar() {
		try {
			tempoSrvc.guardar(this.tempoCadastro);
			this.tempoCadastro = new Tempo();

			FacesUtil.addMsgINFO("Guardado com sucesso");
		} catch (NegocioException erro) {
			FacesUtil.addMsgAviso(erro.getMessage());
		}
	}

	public String remover() {
		try {
			temposRepo.remover(this.tempoCadastro);
			FacesUtil.addMsgINFO("Removido com sucesso");

			return "/paginas/tempo.xhtml?faces-redirect=true";
		} catch (RuntimeException erro) {
			FacesUtil.addMsgERRO("Erro ao remover tempo");
		}
		return null;
	}

	public Tempo getTempoCadastro() {
		return tempoCadastro;
	}

	public void setTempoCadastro(Tempo tempoCadastro) {
		this.tempoCadastro = tempoCadastro;
	}

	public List<Tempo> getTempoFiltrado() {
		return tempoFiltrado;
	}

	public void setTempoFiltrado(List<Tempo> tempoFiltrado) {
		this.tempoFiltrado = tempoFiltrado;
	}

	public List<Tempo> getTodosTempos() {
		return todosTempos;
	}
}
