package mz.sghorario.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import mz.sghorario.modelo.Tempo;
import mz.sghorario.repository.TemposRepo;

@Named
@ViewScoped
public class SeleccaoTempo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private TemposRepo temposRepo;

	private String horaEntrada;
	private List<Tempo> tempoFiltro;

	public void fitroTempoDialogo() {
		this.tempoFiltro = temposRepo.todosDialog(horaEntrada);
	}

	public void abrirDialogo() {
		Map<String, Object> opcoes = new HashMap<>();
		opcoes.put("modal", true);
		opcoes.put("resizable", false);
		opcoes.put("contentHeight", 300);

		RequestContext.getCurrentInstance().openDialog("tempoPesquisa", opcoes,
				null);
	}

	public void selecionar(Tempo tempo) {
		RequestContext.getCurrentInstance().closeDialog(tempo);
	}

	public List<Tempo> getTempoFiltro() {
		return tempoFiltro;
	}

	public void setTempoFiltro(List<Tempo> tempoFiltro) {
		this.tempoFiltro = tempoFiltro;
	}

	public String getHoraEntrada() {
		return horaEntrada;
	}

	public void setHoraEntrada(String horaEntrada) {
		this.horaEntrada = horaEntrada;
	}
}
