package mz.sghorario.bean;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import mz.sghorario.modelo.Usuario;
import mz.sghorario.repository.UsuariosRepo;
import mz.sghorario.util.FacesUtil;

@Named
@SessionScoped
public class AutenticacaoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private UsuariosRepo usuariosRepo;

	@Inject
	private Usuario usuarioLogado;

	public Usuario getUsuarioLogado() {
		if (this.usuarioLogado == null) {
			this.usuarioLogado = new Usuario();
		}
		return usuarioLogado;
	}

	public void setUsuarioLogado(Usuario usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}

	public String logar() {
		try {
			this.usuarioLogado = usuariosRepo.autenticar(
					usuarioLogado.getEmail(), usuarioLogado.getSenha());
			if (this.usuarioLogado != null) {
				return "/paginas/principal.xhtml?faces-redirect=true";
			} else {
				FacesUtil.addMsgAviso("Usuario e senha inválidos");
				return null;
			}
		} catch (RuntimeException e) {
			FacesUtil.addMsgERRO("Usuario e senha inválidos");
			return null;
		}
	}

	public String logOut() {
		FacesContext.getCurrentInstance().getExternalContext()
				.invalidateSession();
		return "/paginas/login.xhtml?faces-redirect=true";
	}

	public boolean isLogado() {
		return usuarioLogado.getFuncao() != null;

	}
}
