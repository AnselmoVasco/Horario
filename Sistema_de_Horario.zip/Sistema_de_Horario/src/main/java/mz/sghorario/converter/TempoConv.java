package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import mz.sghorario.modelo.Tempo;
import mz.sghorario.repository.TemposRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Tempo.class)
public class TempoConv implements Converter {

	private TemposRepo repositorio;

	public TempoConv() {
		this.repositorio = CDILocator.getBean(TemposRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Tempo retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Tempo tempo = (Tempo) value;
			return tempo.getCodigo() == null ? null : tempo.getCodigo()
					.toString();
		}
		return null;
	}
}