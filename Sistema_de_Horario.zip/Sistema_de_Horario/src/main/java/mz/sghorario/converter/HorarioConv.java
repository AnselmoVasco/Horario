package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mz.sghorario.modelo.Horario;
import mz.sghorario.repository.HorariosRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Horario.class)
public class HorarioConv implements Converter {

	private HorariosRepo repositorio;

	public HorarioConv() {
		this.repositorio = CDILocator.getBean(HorariosRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Horario retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Horario horario = (Horario) value;
			return horario.getCodigo() == null ? null : horario.getCodigo()
					.toString();
		}
		return null;
	}
}
