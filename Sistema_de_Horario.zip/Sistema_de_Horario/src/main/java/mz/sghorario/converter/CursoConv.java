package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import mz.sghorario.modelo.Curso;
import mz.sghorario.repository.CursosRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Curso.class)
public class CursoConv implements Converter {
	private CursosRepo repositorio;

	public CursoConv() {
		this.repositorio = CDILocator.getBean(CursosRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Curso retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Curso curso = (Curso) value;
			return curso.getCodigo() == null ? null : curso.getCodigo()
					.toString();
		}
		return null;
	}
}