package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.repository.CadeirasRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Cadeira.class)
public class CadeiraConv implements Converter {

	private CadeirasRepo repositorio;

	public CadeiraConv() {
		this.repositorio = CDILocator.getBean(CadeirasRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Cadeira retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Cadeira cadeira = (Cadeira) value;
			return cadeira.getCodigo() == null ? null : cadeira.getCodigo()
					.toString();
		}
		return null;
	}
}
