package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mz.sghorario.modelo.Usuario;
import mz.sghorario.repository.UsuariosRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Usuario.class)
public class UsuarioConv implements Converter {

	private UsuariosRepo repositorio;

	public UsuarioConv() {
		this.repositorio = CDILocator.getBean(UsuariosRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Usuario retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Usuario usuario = (Usuario) value;
			return usuario.getCodigo() == null ? null : usuario.getCodigo()
					.toString();
		}
		return null;
	}
}