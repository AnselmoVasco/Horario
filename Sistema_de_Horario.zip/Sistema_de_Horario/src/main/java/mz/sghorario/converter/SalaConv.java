package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import mz.sghorario.modelo.Sala;
import mz.sghorario.repository.SalasRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Sala.class)
public class SalaConv implements Converter {

	private SalasRepo repositorio;

	public SalaConv() {
		this.repositorio = CDILocator.getBean(SalasRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Sala retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Sala sala = (Sala) value;
			return sala.getCodigo() == null ? null : sala.getCodigo()
					.toString();
		}
		return null;
	}
}
