package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import mz.sghorario.modelo.Departamento;
import mz.sghorario.repository.DepartamentosRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Departamento.class)
public class DepartamentoConv implements Converter {

	private DepartamentosRepo repositorio;

	public DepartamentoConv() {
		this.repositorio = CDILocator.getBean(DepartamentosRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Departamento retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Departamento departamento = ((Departamento) value);
			return departamento.getCodigo() == null ? null : departamento
					.getCodigo().toString();
		}
		return null;
	}
}
