package mz.sghorario.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import mz.sghorario.modelo.Professor;
import mz.sghorario.repository.ProfessoresRepo;
import mz.sghorario.util.CDILocator;

@FacesConverter(forClass = Professor.class)
public class ProfessorConv implements Converter {

	private ProfessoresRepo repositorio;

	public ProfessorConv() {
		this.repositorio = CDILocator.getBean(ProfessoresRepo.class);
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		Professor retorno = null;
		if (value != null) {
			retorno = this.repositorio.buscar(new Long(value));
		}
		return retorno;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		if (value != null) {
			Professor professor = (Professor) value;
			return professor.getCodigo() == null ? null : professor.getCodigo()
					.toString();
		}
		return null;
	}
}