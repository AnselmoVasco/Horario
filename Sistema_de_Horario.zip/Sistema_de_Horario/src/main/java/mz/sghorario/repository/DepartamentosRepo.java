package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Departamento;
import mz.sghorario.util.Transactional;

public class DepartamentosRepo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Departamento departamento) {
		this.manager.merge(departamento);
	}

	public Departamento buscar(Long codigo) {
		return manager.find(Departamento.class, codigo);
	}

	@Transactional
	public void remover(Departamento departamento) {
		departamento = buscar(departamento.getCodigo());
		this.manager.remove(departamento);
		this.manager.flush();
	}

	public List<Departamento> todos() {
		TypedQuery<Departamento> query = manager.createQuery(
				"FROM Departamento", Departamento.class);
		return query.getResultList();
	}

	public Departamento mesmoNome(String nome) {
		try {
			return manager
					.createQuery("from Departamento where upper(nome) =:nome",
							Departamento.class)
					.setParameter("nome", nome.toUpperCase()).getSingleResult();

		} catch (NoResultException e) {

			return null;
		}

	}

	public Departamento mesmaSigla(String sigla) {
		try {
			return manager
					.createQuery(
							"from Departamento where upper(sigla) =:sigla",
							Departamento.class)
					.setParameter("sigla", sigla.toUpperCase())
					.getSingleResult();

		} catch (NoResultException e) {

			return null;
		}

	}

	public List<Departamento> todosDialog(String nome) {
		return manager
				.createQuery("FROM Departamento WHERE nome LIKE :nome",
						Departamento.class)
				.setParameter("nome", "%" + nome + "%").getResultList();
	}

	public List<String> departamentoQueContem(String nome) {
		TypedQuery<String> query = manager
				.createQuery(
						"select nome from Departamento where upper(nome) like upper(:nome)",
						String.class);
		query.setParameter("nome", "%" + nome + "%");
		return query.getResultList();
	}

}
