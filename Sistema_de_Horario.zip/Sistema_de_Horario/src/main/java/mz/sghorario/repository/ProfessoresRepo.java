package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Professor;
import mz.sghorario.util.Transactional;

public class ProfessoresRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Professor professor) {
		this.manager.merge(professor);
	}

	public Professor buscar(Long codigo) {
		return manager.find(Professor.class, codigo);
	}

	@Transactional
	public void remover(Professor professor) {
		professor = buscar(professor.getCodigo());
		this.manager.remove(professor);
		this.manager.flush();
	}

	public List<Professor> todos() {
		TypedQuery<Professor> query = manager.createQuery("FROM Professor",
				Professor.class);
		return query.getResultList();
	}

	public Professor bilheteExiste(String bilhete) {
		try {
			return manager
					.createQuery(
							"from Professor where upper(bilhete) =:bilhete",
							Professor.class)
					.setParameter("bilhete", bilhete.toUpperCase())
					.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Professor> todosDialog(String nome) {
		return manager
				.createQuery("FROM Professor WHERE nome LIKE :nome",
						Professor.class).setParameter("nome", "%" + nome + "%")
				.getResultList();
	}

	
}
