package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Tempo;
import mz.sghorario.util.Transactional;

public class TemposRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Tempo tempo) {
		this.manager.merge(tempo);
	}

	public Tempo buscar(Long codigo) {
		return manager.find(Tempo.class, codigo);
	}

	@Transactional
	public void remover(Tempo tempo) {
		tempo = buscar(tempo.getCodigo());
		this.manager.remove(tempo);
	}

	public List<Tempo> todos() {
		TypedQuery<Tempo> query = manager
				.createQuery("FROM Tempo", Tempo.class);
		return query.getResultList();
	}

	public Tempo restricao(String horaEntrada, String horaSaida) {
		try {
			return manager
					.createQuery(
							"from Tempo where upper(horaEntrada) =:horaEntrada and upper(horaSaida) =:horaSaida",
							Tempo.class)
					.setParameter("horaEntrada", horaEntrada.toUpperCase())
					.setParameter("horaSaida", horaSaida).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}

	}

	public List<Tempo> todosDialog(String horaEntrada) {
		return manager
				.createQuery("FROM Tempo WHERE horaEntrada LIKE :horaEntrada",
						Tempo.class)
				.setParameter("horaEntrada", "%" + horaEntrada + "%")
				.getResultList();
	}

}
