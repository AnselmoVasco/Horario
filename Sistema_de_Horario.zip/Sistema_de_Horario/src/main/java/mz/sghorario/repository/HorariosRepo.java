package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.filter.HorarioFiltro;
import mz.sghorario.modelo.EnumDias;
import mz.sghorario.modelo.EnumPeriodo;
import mz.sghorario.modelo.EnumSemestre;
import mz.sghorario.modelo.Horario;
import mz.sghorario.util.Transactional;

public class HorariosRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Horario horario) {
		this.manager.merge(horario);
	}

	public Horario buscar(Long codigo) {
		return manager.find(Horario.class, codigo);
	}

	@Transactional
	public void remover(Horario horario) {
		horario = buscar(horario.getCodigo());
		this.manager.remove(horario);
		this.manager.flush();
	}

	public List<Horario> todos() {
		TypedQuery<Horario> query = manager.createQuery("FROM Horario",
				Horario.class);
		return query.getResultList();
	}

	public Horario salaOcupada(EnumDias dias, Long tempo, Long sala,
			EnumSemestre semestre) {
		try {
			return manager
					.createQuery(
							"from Horario where upper(dias) =:dias and upper(tempo.codigo) =:tempo "
									+ "and upper(sala.codigo) =:sala and upper(semestre) =:semestre",
							Horario.class).setParameter("dias", dias)
					.setParameter("tempo", tempo).setParameter("sala", sala)
					.setParameter("semestre", semestre).getSingleResult();
		} catch (NoResultException e) {

			return null;
		}
	}

	public Horario professorOcupado(EnumDias dias, EnumSemestre semestre,
			Long tempo, Long professor) {
		try {
			return manager
					.createQuery(
							"from Horario where upper(dias) =:dias and upper(semestre) =:semestre "
									+ "and upper(tempo.codigo) =:tempo and upper(professor.codigo) =:professor",
							Horario.class).setParameter("dias", dias)
					.setParameter("semestre", semestre)
					.setParameter("tempo", tempo)
					.setParameter("professor", professor).getSingleResult();
		} catch (NoResultException e) {

			return null;
		}
	}

	public Horario HorarioLancado(Long curso, EnumDias dias, String ano,
			EnumSemestre semestre, EnumPeriodo periodo, Long tempo) {
		try {
			return manager
					.createQuery(
							"from Horario where upper(curso.codigo) =:curso and upper(dias) =:dias "
									+ "and upper(ano) =:ano and upper(semestre) =:semestre "
									+ "and upper(periodo) =:periodo and upper(tempo.codigo) =:tempo",
							Horario.class).setParameter("curso", curso)
					.setParameter("dias", dias).setParameter("ano", ano)
					.setParameter("semestre", semestre)
					.setParameter("periodo", periodo)
					.setParameter("tempo", tempo).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Horario> consultar(HorarioFiltro filtro) {

		List<Horario> horarios = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT horario FROM Horario horario ");

		if (filtro.getAno() != null && filtro.getCurso() != null
				&& filtro.getSemestre() != null && filtro.getPeriodo() != null
				&& filtro.getAnoLectivo() != null) {
			sql.append("WHERE horario.curso.codigo = :curso AND "
					+ "horario.ano = :ano AND "
					+ "horario.semestre = :semestre AND "
					+ "horario.periodo = :periodo AND "
					+ "horario.anoActual = :anoActual");
		}
		TypedQuery<Horario> query = manager
				.createQuery(sql.toString(), Horario.class)
				.setParameter("ano", filtro.getAno())
				.setParameter("curso", filtro.getCurso())
				.setParameter("semestre", filtro.getSemestre())
				.setParameter("periodo", filtro.getPeriodo())
				.setParameter("anoActual", filtro.getAnoLectivo());

		horarios = query.getResultList();

		return horarios;

	}

}
