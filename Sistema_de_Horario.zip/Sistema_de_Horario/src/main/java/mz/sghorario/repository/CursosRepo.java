package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Curso;
import mz.sghorario.modelo.EnumNivel;
import mz.sghorario.util.Transactional;

public class CursosRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Curso curso) {
		this.manager.merge(curso);
	}

	public Curso buscar(Long codigo) {
		return manager.find(Curso.class, codigo);

	}

	@Transactional
	public void remover(Curso curso) {
		curso = buscar(curso.getCodigo());
		this.manager.remove(curso);
		this.manager.flush();
	}

	public List<Curso> todos() {
		TypedQuery<Curso> query = manager
				.createQuery("FROM Curso", Curso.class);
		return query.getResultList();
	}

	public Curso cursoExiste(String nome, EnumNivel nivel) {
		try {
			return manager
					.createQuery(
							"from Curso where upper(nome) =:nome and upper(nivel) =:nivel",
							Curso.class)
					.setParameter("nome", nome.toUpperCase())
					.setParameter("nivel", nivel).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}

	}

	public List<Curso> todosDialog(String nome) {
		return manager
				.createQuery("FROM Curso WHERE nome LIKE :nome", Curso.class)
				.setParameter("nome", "%" + nome + "%").getResultList();
	}
}
