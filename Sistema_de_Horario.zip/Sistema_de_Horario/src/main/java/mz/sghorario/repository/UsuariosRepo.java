package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Usuario;
import mz.sghorario.util.Transactional;

public class UsuariosRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Usuario usuario) {
		this.manager.merge(usuario);
	}

	public Usuario buscar(Long codigo) {
		return manager.find(Usuario.class, codigo);
	}

	@Transactional
	public void remover(Usuario usuario) {
		usuario = buscar(usuario.getCodigo());
		this.manager.remove(usuario);
		this.manager.flush();
	}

	public List<Usuario> todos() {
		TypedQuery<Usuario> query = manager.createQuery("FROM Usuario",
				Usuario.class);
		return query.getResultList();
	}

	public Usuario enderecoUnico(String email) {
		try {
			return manager
					.createQuery("FROM Usuario WHERE upper(email) =:email",
							Usuario.class)
					.setParameter("email", email.toUpperCase())
					.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public Usuario bilheteExiste(String bilhete) {
		try {
			return manager
					.createQuery("from Usuario where upper(bilhete) =:bilhete",
							Usuario.class)
					.setParameter("bilhete", bilhete.toUpperCase())
					.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public Usuario numeroExiste(String numeroTelefone) {
		try {
			return manager
					.createQuery(
							"from Usuario where upper(numeroTelefone) =:numeroTelefone",
							Usuario.class)
					.setParameter("numeroTelefone",
							numeroTelefone.toUpperCase()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public Usuario autenticar(String email, String senha) {
		Query query = manager
				.createQuery(
						"SELECT usuario FROM Usuario usuario WHERE usuario.email = :email AND usuario.senha = :senha")
				.setParameter("email", email).setParameter("senha", senha);
		return (Usuario) query.getSingleResult();
	}
}
