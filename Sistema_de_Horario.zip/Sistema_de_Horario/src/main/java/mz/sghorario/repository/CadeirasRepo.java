package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Cadeira;
import mz.sghorario.util.Transactional;

public class CadeirasRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Cadeira cadeira) {
		this.manager.merge(cadeira);
	}

	public Cadeira buscar(Long codigo) {
		return manager.find(Cadeira.class, codigo);
	}

	@Transactional
	public void remover(Cadeira cadeira) {
		cadeira = buscar(cadeira.getCodigo());
		this.manager.remove(cadeira);
	}

	public List<Cadeira> todas() {
		TypedQuery<Cadeira> query = manager.createQuery("FROM Cadeira",
				Cadeira.class);
		return query.getResultList();
	}

	public Cadeira mesmoNome(String nome) {

		try {
			return manager
					.createQuery("from Cadeira where upper(nome) =:nome",
							Cadeira.class)
					.setParameter("nome", nome.toUpperCase()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Cadeira> todosDialog(String nome) {
		return manager
				.createQuery("FROM Cadeira WHERE nome LIKE :nome",
						Cadeira.class).setParameter("nome", "%" + nome + "%")
				.getResultList();
	}
}
