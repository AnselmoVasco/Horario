package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Sala;
import mz.sghorario.util.Transactional;

public class SalasRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public void adicionar(Sala sala) {
		this.manager.merge(sala);
	}

	public Sala buscar(Long codigo) {
		return manager.find(Sala.class, codigo);
	}

	@Transactional
	public void remover(Sala sala) {
		sala = buscar(sala.getCodigo());
		this.manager.remove(sala);
		this.manager.flush();
	}

	public List<Sala> todas() {
		TypedQuery<Sala> query = manager.createQuery("FROM Sala", Sala.class);
		return query.getResultList();
	}

	public Sala salaExiste(String nome) {
		try {
			return manager
					.createQuery("FROM Sala where upper(nome) =:nome",
							Sala.class)
					.setParameter("nome", nome.toUpperCase()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public List<Sala> todosDialog(String nome) {
		return manager
				.createQuery("FROM Sala WHERE nome LIKE :nome", Sala.class)
				.setParameter("nome", "%" + nome + "%").getResultList();
	}
}
