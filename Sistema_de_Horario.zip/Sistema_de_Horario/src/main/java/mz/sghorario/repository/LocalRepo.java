package mz.sghorario.repository;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import mz.sghorario.modelo.Local;
import mz.sghorario.util.Transactional;

public class LocalRepo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private EntityManager manager;

	public Local buscarPorCodigo(Long codigo) {
		return manager.find(Local.class, codigo);
	}

	@Transactional
	public void adicionar(Local local) {
		this.manager.merge(local);
	}

	@Transactional
	public void remover(Local local) {
		local = buscarPorCodigo(local.getCodigo());
		this.manager.remove(local);
		this.manager.flush();
	}

	public List<Local> listarLocaisPorProfessor(Long codigo) {

		TypedQuery<Local> query = manager.createQuery(
				"FROM Local where upper(professor.codigo) =:codigo",
				Local.class).setParameter("codigo", codigo);
		return query.getResultList();
	}
}