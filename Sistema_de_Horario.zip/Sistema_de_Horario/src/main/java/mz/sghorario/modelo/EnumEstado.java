package mz.sghorario.modelo;

public enum EnumEstado {
	Disponivel, Ocupada
}
