package mz.sghorario.modelo;

public enum EnumPeriodo {
	Laboral, Pos_Laboral
}
