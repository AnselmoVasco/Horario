package mz.sghorario.modelo;

public enum EnumFuncao {
	Adiministrador, Professor, Estudante, Coordenador
}
