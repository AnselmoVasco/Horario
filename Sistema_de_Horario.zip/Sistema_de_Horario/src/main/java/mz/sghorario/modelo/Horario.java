package mz.sghorario.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "tbl_horarios")
public class Horario implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long codigo;
	private EnumSemestre semestre;
	private Professor professor;
	private Curso curso;
	private EnumDias dias;
	private EnumPeriodo periodo;
	private Tempo tempo;
	private Cadeira cadeira;
	private Sala sala;
	private String ano;
	private EnumAnos anoActual;

	@Id
	@GeneratedValue
	@Column(name = "hora_codigo")
	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	public EnumDias getDias() {
		return dias;
	}

	public void setDias(EnumDias dias) {
		this.dias = dias;
	}

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	public EnumPeriodo getPeriodo() {
		return periodo;
	}

	public void setPeriodo(EnumPeriodo periodo) {
		this.periodo = periodo;
	}

	@NotNull
	@ManyToOne(optional = false)
	@JoinColumn(name = "temp_codigo")
	public Tempo getTempo() {
		return tempo;
	}

	public void setTempo(Tempo tempo) {
		this.tempo = tempo;
	}

	@NotNull
	@ManyToOne(optional = false)
	@JoinColumn(name = "cad_codigo")
	public Cadeira getCadeira() {
		return cadeira;
	}

	public void setCadeira(Cadeira cadeira) {
		this.cadeira = cadeira;
	}

	@NotNull
	@ManyToOne(optional = false)
	@JoinColumn(name = "sal_codigo")
	public Sala getSala() {
		return sala;
	}

	public void setSala(Sala sala) {
		this.sala = sala;
	}

	@NotNull
	@ManyToOne(optional = false)
	@JoinColumn(name = "cur_codigo")
	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	@NotNull
	@ManyToOne(optional = false)
	@JoinColumn(name = "pro_codigo")
	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	public EnumSemestre getSemestre() {
		return semestre;
	}

	public void setSemestre(EnumSemestre semestre) {
		this.semestre = semestre;
	}

	@NotEmpty
	@Column(name = "hora_ano", nullable = false)
	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	public EnumAnos getAnoActual() {
		return anoActual;
	}

	public void setAnoActual(EnumAnos anoActual) {
		this.anoActual = anoActual;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Horario other = (Horario) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

}
