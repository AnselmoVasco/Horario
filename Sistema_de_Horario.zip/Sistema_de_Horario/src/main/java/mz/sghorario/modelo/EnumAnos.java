package mz.sghorario.modelo;

public enum EnumAnos {

	_2015_, _2016_, _2017_, _2018_, _2019_, _2020_
}
