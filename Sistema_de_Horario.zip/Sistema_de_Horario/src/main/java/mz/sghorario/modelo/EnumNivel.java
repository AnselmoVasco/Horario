package mz.sghorario.modelo;

public enum EnumNivel {
	Licenciatura, Mestrado
}
