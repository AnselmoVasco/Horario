package mz.sghorario.modelo;

public enum EnumSemestre {
	Primeiro, Segundo
}
