package mz.sghorario.modelo;

public enum EnumDias {
	Segunda_Feira, Terça_Feira, Quarta_Feira, Quinta_Feira, Sexta_Feira
}
