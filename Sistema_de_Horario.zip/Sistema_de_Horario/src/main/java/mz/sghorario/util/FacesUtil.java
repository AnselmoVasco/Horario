package mz.sghorario.util;

import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

public class FacesUtil {

	public static void addMsgINFO(String menssagem) {
		FacesMessage facesMessage = new FacesMessage(
				FacesMessage.SEVERITY_INFO, menssagem, menssagem);
		FacesContext facesContext = FacesContext.getCurrentInstance();

		ExternalContext externalContext = facesContext.getExternalContext();
		Flash flash = externalContext.getFlash();
		flash.setKeepMessages(true);
		facesContext.addMessage(null, facesMessage);
	}

	public static void addMsgERRO(String menssagem) {

		FacesMessage facesMessage = new FacesMessage(
				FacesMessage.SEVERITY_ERROR, menssagem, menssagem);
		FacesContext facesContext = FacesContext.getCurrentInstance();
		facesContext.addMessage(null, facesMessage);

	}

	public static void addMsgAviso(String menssagem) {

		FacesMessage facesMessage = new FacesMessage(
				FacesMessage.SEVERITY_WARN, menssagem, menssagem);
		FacesContext facesContext = FacesContext.getCurrentInstance();
		facesContext.addMessage(null, facesMessage);

	}

	public static String getParam(String nome) {
		FacesContext facesContext = FacesContext.getCurrentInstance();

		ExternalContext externalContext = facesContext.getExternalContext();
		Flash flash = externalContext.getFlash();
		flash.setKeepMessages(true);
		Map<String, String> parametros = externalContext
				.getRequestParameterMap();
		String valor = parametros.get(nome);

		return valor;
	}
}