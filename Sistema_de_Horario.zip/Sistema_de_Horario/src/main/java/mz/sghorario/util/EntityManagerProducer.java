package mz.sghorario.util;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

@ApplicationScoped
public class EntityManagerProducer {

	private EntityManagerFactory factory;

	public EntityManagerProducer() {
		this.factory = Persistence.createEntityManagerFactory("SGhoraPU");
	}

	@Produces
	@ApplicationScoped
	public EntityManager criaEntityManager() {
		return factory.createEntityManager();
	}

	public void fechaEntityManager(@Disposes EntityManager manager) {
		manager.close();
	}
}
